/*************************************************************
 * MC Rubber - ระบบออกบิลเชื่อม Google Sheets
 * -----------------------------------------------------------
 * ไฟล์นี้เป็น Google Apps Script (Code.gs) ที่ต้องนำไปวางใน
 * Apps Script Project (ผูกกับ Google Sheet หรือแบบ Standalone
 * ก็ได้ เพราะเราระบุ Spreadsheet ID ตรงๆ ใน CONFIG ด้านล่าง)
 *
 * *** สิ่งที่ต้องตรวจสอบ/แก้ก่อนใช้งานจริง ***
 * ผมไม่สามารถอ่านหัวคอลัมน์ที่แท้จริงของชีต "ลูกค้า" (gid
 * 1457347753) และชีต "Input" (gid 0) ได้ตรงๆ (เครื่องมือที่มี
 * ดึงได้แค่ชีตแรกสุดของไฟล์ ซึ่งเป็นคนละแท็บ) จึงตั้งชื่อหัว
 * คอลัมน์ไว้แบบที่พบได้บ่อยที่สุด - เปิดชีตจริงแล้วแก้ค่าใน
 * CONFIG.CUSTOMER_HEADERS / CONFIG.PRODUCT_HEADERS ให้ตรงกับ
 * หัวตารางจริงในแถวแรกของแต่ละชีต (ไม่ต้องแก้โค้ดส่วนอื่น)
 *************************************************************/

const CONFIG = {
  // --- ไฟล์ฐานข้อมูลลูกค้า ---
  CUSTOMER_SPREADSHEET_ID: '10CKvV_LlHRoc__qRw7nulocCu4kuO92eNlBiRBVn2zw',
  CUSTOMER_SHEET_GID: 1457347753, // แท็บที่เก็บข้อมูลลูกค้า

  // --- ไฟล์ฐานข้อมูลสินค้า ---
  PRODUCT_SPREADSHEET_ID: '1O2c_iDKBYkbFNC0NIEopu2jRcUpBA-4php69c0S4lWc',
  PRODUCT_SHEET_GID: 0, // แท็บ "Input"

  // --- ที่เก็บบิลที่ออกแล้ว (จะสร้างแท็บนี้ให้อัตโนมัติถ้ายังไม่มี) ---
  INVOICE_LOG_SPREADSHEET_ID: '10CKvV_LlHRoc__qRw7nulocCu4kuO92eNlBiRBVn2zw',
  INVOICE_LOG_SHEET_NAME: 'บันทึกบิล',

  // --- ชื่อหัวคอลัมน์ในแถวแรกของชีตลูกค้า (แก้ให้ตรงกับของจริง) ---
  CUSTOMER_HEADERS: {
    id: 'รหัสลูกค้า',
    name: 'ชื่อลูกค้า',
    taxId: 'เลขประจำตัวผู้เสียภาษี',
    address1: 'ที่อยู่ 1',
    address2: 'ที่อยู่ 2'
  },

  // --- ชื่อหัวคอลัมน์ในแถวแรกของชีตสินค้า (แก้ให้ตรงกับของจริง) ---
  PRODUCT_HEADERS: {
    code: 'MC Product',
    name: 'ชื่อสินค้า',
    price: 'ราคา',
    unit: 'หน่วย'
  }
};

/*************************************************************
 * Web App entry point
 *************************************************************/
function doGet() {
  return HtmlService.createHtmlOutputFromFile('Index')
    .setTitle('MC Rubber - ระบบออกบิล')
    .addMetaTag('viewport', 'width=device-width, initial-scale=1');
}

/*************************************************************
 * Helpers ทั่วไป
 *************************************************************/

// หา Sheet จาก gid (กันปัญหาถ้ามีคนเปลี่ยนชื่อแท็บภายหลัง)
function getSheetByGid_(spreadsheetId, gid) {
  const ss = SpreadsheetApp.openById(spreadsheetId);
  const sheets = ss.getSheets();
  for (let i = 0; i < sheets.length; i++) {
    if (sheets[i].getSheetId() === gid) return sheets[i];
  }
  throw new Error('ไม่พบแท็บที่มี gid=' + gid + ' ในไฟล์ ' + spreadsheetId);
}

// อ่านทั้งชีตแล้วแปลงเป็น array ของ object โดยใช้แถวแรกเป็นหัวคอลัมน์
function sheetToObjects_(sheet) {
  const data = sheet.getDataRange().getValues();
  if (data.length < 2) return { headers: data[0] || [], rows: [] };
  const headers = data[0].map(h => String(h).trim());
  const rows = data.slice(1)
    .filter(r => r.join('') !== '') // ข้ามแถวว่าง
    .map((r, idx) => {
      const obj = { _row: idx + 2 }; // เลขแถวจริงในชีต (สำหรับอ้างอิงภายหลัง)
      headers.forEach((h, i) => { obj[h] = r[i]; });
      return obj;
    });
  return { headers, rows };
}

function colIndex_(headers, headerName) {
  const idx = headers.indexOf(headerName);
  if (idx === -1) {
    throw new Error('ไม่พบคอลัมน์ชื่อ "' + headerName + '" ในชีต กรุณาตรวจสอบ CONFIG ให้ตรงกับหัวตารางจริง');
  }
  return idx;
}

/*************************************************************
 * ลูกค้า
 *************************************************************/

// ดึงรายชื่อลูกค้าทั้งหมด -> ใช้ในหน้าออกบิล (dropdown) และหน้าจัดการลูกค้า
function getCustomers() {
  const sheet = getSheetByGid_(CONFIG.CUSTOMER_SPREADSHEET_ID, CONFIG.CUSTOMER_SHEET_GID);
  const { headers, rows } = sheetToObjects_(sheet);
  const H = CONFIG.CUSTOMER_HEADERS;

  return rows.map(r => ({
    id: r[H.id] || '',
    name: r[H.name] || '',
    taxId: r[H.taxId] || '',
    address1: r[H.address1] || '',
    address2: r[H.address2] || '',
    // ที่อยู่รวม (สำหรับแสดงในใบบิล)
    address: [r[H.address1], r[H.address2]].filter(Boolean).join(' ')
  })).filter(c => c.name);
}

// เพิ่มลูกค้าใหม่: { name, taxId, address1, address2 }
function addCustomer(customer) {
  if (!customer || !customer.name) {
    throw new Error('กรุณากรอกชื่อลูกค้า');
  }
  const sheet = getSheetByGid_(CONFIG.CUSTOMER_SPREADSHEET_ID, CONFIG.CUSTOMER_SHEET_GID);
  const { headers, rows } = sheetToObjects_(sheet);
  const H = CONFIG.CUSTOMER_HEADERS;

  // สร้างรหัสลูกค้าใหม่อัตโนมัติ (เลขถัดไปจากรหัสที่มากที่สุด รูปแบบ C0001)
  let nextIdNumber = 1;
  rows.forEach(r => {
    const idVal = String(r[H.id] || '');
    const num = parseInt(idVal.replace(/\D/g, ''), 10);
    if (!isNaN(num) && num >= nextIdNumber) nextIdNumber = num + 1;
  });
  const newId = 'C' + String(nextIdNumber).padStart(4, '0');

  // สร้างแถวใหม่ให้ตรงลำดับคอลัมน์จริงในชีต
  const newRow = new Array(headers.length).fill('');
  newRow[colIndex_(headers, H.id)] = newId;
  newRow[colIndex_(headers, H.name)] = customer.name;
  newRow[colIndex_(headers, H.taxId)] = customer.taxId || '';
  newRow[colIndex_(headers, H.address1)] = customer.address1 || '';
  newRow[colIndex_(headers, H.address2)] = customer.address2 || '';

  sheet.appendRow(newRow);
  return { id: newId, name: customer.name };
}

/*************************************************************
 * สินค้า
 *************************************************************/

// ดึงรายการสินค้าทั้งหมดจากชีต Input -> ใช้ในหน้าค้นหาสินค้า และช่วยกรอกบิล
function getProducts() {
  const sheet = getSheetByGid_(CONFIG.PRODUCT_SPREADSHEET_ID, CONFIG.PRODUCT_SHEET_GID);
  const { rows } = sheetToObjects_(sheet);
  const H = CONFIG.PRODUCT_HEADERS;

  return rows.map(r => ({
    code: r[H.code] || '',
    name: r[H.name] || '',
    price: Number(r[H.price]) || 0,
    unit: r[H.unit] || ''
  })).filter(p => p.name);
}

/*************************************************************
 * บันทึกบิล
 *************************************************************/

function getOrCreateInvoiceLogSheet_() {
  const ss = SpreadsheetApp.openById(CONFIG.INVOICE_LOG_SPREADSHEET_ID);
  let sheet = ss.getSheetByName(CONFIG.INVOICE_LOG_SHEET_NAME);
  if (!sheet) {
    sheet = ss.insertSheet(CONFIG.INVOICE_LOG_SHEET_NAME);
    sheet.appendRow([
      'เลขที่บิล', 'วันที่', 'รหัสลูกค้า', 'ชื่อลูกค้า', 'ที่อยู่', 'เลขผู้เสียภาษี',
      'สินค้า', 'MC Product', 'จำนวน', 'หน่วย', 'ราคา/หน่วย', 'รวมเงิน',
      'ยอดก่อนVAT', 'VAT', 'ยอดสุทธิ', 'บันทึกเมื่อ'
    ]);
  }
  return sheet;
}

// บันทึกบิล 1 ใบ (หลายรายการสินค้า) ลง 1 แถวต่อ 1 รายการสินค้า
function saveInvoiceData(invoice) {
  if (!invoice || !invoice.customerId) {
    throw new Error('กรุณาเลือกลูกค้าก่อนบันทึกบิล');
  }
  const sheet = getOrCreateInvoiceLogSheet_();
  const subTotal = invoice.items.reduce((s, it) => s + (Number(it.quantity) * Number(it.price)), 0);
  const vat = subTotal * 0.07;
  const grandTotal = subTotal + vat;
  const now = new Date();

  invoice.items.forEach(item => {
    sheet.appendRow([
      invoice.orderNo,
      invoice.date,
      invoice.customerId,
      invoice.customerName,
      invoice.customerAddress,
      invoice.taxId,
      item.product,
      item.mcProduct,
      item.quantity,
      item.unit,
      item.price,
      Number(item.quantity) * Number(item.price),
      subTotal,
      vat,
      grandTotal,
      now
    ]);
  });

  return 'บันทึกบิลเลขที่ ' + invoice.orderNo + ' เรียบร้อยแล้ว (' + invoice.items.length + ' รายการ)';
}
